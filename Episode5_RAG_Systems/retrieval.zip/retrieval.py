from langchain_openai import OpenAIEmbeddings
from langchain_qdrant import QdrantVectorStore
from openai import OpenAI
from dotenv import load_dotenv

# load the env file
load_dotenv()

client = OpenAI()

# vector embeddings
embedding_model = OpenAIEmbeddings(
    model = "text-embedding-3-large"
)

# retrieve the relevant context from the vector db
vector_db = QdrantVectorStore.from_existing_collection(
    url = "http://localhost:6333",
    collection_name = "vector_embeddings",
    embedding=embedding_model
)

# take the user query
user_query = input("Enter your query: ")

# similarity search
search_results = vector_db.similarity_search(
    query = user_query
)

relevant_context = "\n\n\n".join([f"Page Content: {result.page_content} \n Page Number: {result.metadata['page_label']} \n File Location: {result.metadata['source']}" for result in search_results])

SYSTEM_PROMPT = f"""
You are a helpful AI assistant who answers the user
query based on the available context retrieved from the
PDF file along with page content and page number.

You should only answer the user based on the following context
and navigate the user to open the right page number to 
know more about it.

Context: {relevant_context}
"""

chat_completion = client.chat.completions.create(
    model = "gpt-4.1",
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_query}
    ]
)

print(f"Result: {chat_completion.choices[0].message.content}")