from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_qdrant import QdrantVectorStore
from openai import OpenAI
from dotenv import load_dotenv
from pathlib import Path

# load the env file
load_dotenv()

client = OpenAI()

# step 1: loading the legal file => "Ace the DS Interview"
pdf_path = Path(__file__).parent/"Ace the Data Science Interview (Nick Singh  Kevin Huo).pdf"
loader = PyPDFLoader(file_path=pdf_path)
docs = loader.load()

# step 2: chunking = split the doc into multiple chunks
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size = 1000,
    chunk_overlap = 300 # context understanding
)

split_docs = text_splitter.split_documents(documents=docs)

# step 3: convert the textual data into vector embeddings
embedding_model = OpenAIEmbeddings(
    model = "text-embedding-3-large"
)

# step 4: store the vector embeddings into vector db
vector_db = QdrantVectorStore.from_documents(
    documents=split_docs,
    url = "http://localhost:6333",
    collection_name = "vector_embeddings",
    embedding=embedding_model
)

print('Indexing of the documents done!!!')