from typing_extensions import TypedDict
from openai import OpenAI
from dotenv import load_dotenv
from langgraph.graph import StateGraph, START, END

load_dotenv()

client = OpenAI()

class State(TypedDict):
    query: str
    llm_result: str | None


def chatbot(state: State):
    query = state['query']
    llm_response = client.chat.completions.create(
        model = 'gpt-4.1',
        messages=[
            {"role":"user", "content":query}
        ]
    )

    result = llm_response.choices[0].message.content
    state['llm_result'] = result
    return state

graph_builder = StateGraph(State)
graph_builder.add_node("chatbot", chatbot)

graph_builder.add_edge(START, "chatbot")
graph_builder.add_edge("chatbot", END)

graph = graph_builder.compile()

def main():
    user_query = input("Enter your query: ")
    # invoke the graph
    _state = {
        "query": user_query,
        "llm_result": None
    }

    graph_result = graph.invoke(_state)
    print("graph result: ", graph_result)

# function call
main()
